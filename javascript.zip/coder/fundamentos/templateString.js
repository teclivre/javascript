const name = 'Mel'
const concat = 'Olá,' + name + '!!'
console.log(concat);

const template = `
    Olá, 
    ${name}`
console.log(template)    

//expressoẽs 
console.log(`1 + 1 = ${1 + 1}`)
const up = texto => texto.toUpperCase()
console.log(`Olá ${up ('cuidado')}!`)
     

