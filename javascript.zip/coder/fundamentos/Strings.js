const escola = "teclivre"
console.log(escola.charAt(2))
console.log(escola.charAt(9))
console.log(escola.charCodeAt(3))
console.log(escola.lastIndexOf("3"))
console.log(escola.substring(3))
console.log(escola.substring(0,2))

console.log('Escola '.concat(escola).concat("!"))

console.log(escola.replace(2, 'm'))

console.log('Roberio,Mel,Aline,Noah'.split(','))
