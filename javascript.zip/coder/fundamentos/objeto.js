const prod1 = {}
prod1.nome = 'Celular Ultra Mega'
prod1.preco = 4998.89
console.log(prod1)

const prod2 = {
    Nome: 'Camisa Polo',
    Preço: 79.90, 
    bero: "oi"
}

console.log(prod2)