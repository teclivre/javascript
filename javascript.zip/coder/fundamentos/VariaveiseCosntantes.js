var a = 3
let b = 5

var a  = 30
b = 40

console.log(a, b)

const c = 55
console.log(c)