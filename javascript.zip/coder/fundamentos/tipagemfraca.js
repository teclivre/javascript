let qualquer = "Legal!"
console.log(qualquer)
console.log(typeof qualquer)

qualquer = 3.14
console.log(qualquer)
console.log(typeof qualquer)
// Evitar nomes genericos e siglas tipo:

let = valor = ""
let = numero = 3.14
let = pqp = false // não da pra saber  do que se trata.