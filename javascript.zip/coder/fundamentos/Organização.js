console.log("Sentença de Códigos.");

{
    {
        console.log("Olá mundo!")
        console.log("Brasil")
    }

}