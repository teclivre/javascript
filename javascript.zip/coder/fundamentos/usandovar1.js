{
    {
        {
            {var sera = 'Será???'
        }
        }
    }
}
console.log(sera)

function teste(){
    var local = 123 //variavel dentro de uma fução, só é visivel dentro da função.
console.log(local)  // Só é mostrada dentro da função
}

teste()
