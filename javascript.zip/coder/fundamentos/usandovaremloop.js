for(var i = 0; i < 12; i++){
    console.log(i)
}
console.log('i = ', i)