
console.log( 'a = ', a)
var a = 2 
console.log('a = ',a)

 // console.log('b= b' b) //Neste caso não reconhece a função
let b = 3
console.log(`b = ${b}`)