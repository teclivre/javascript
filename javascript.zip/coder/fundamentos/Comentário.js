// Comentário de uma linha.
console.log("Linha 1")

/*
Comentários
em varias linha
*/
console.log("Linha 2")

/*
* Comentério 1
* Comentário 2
*/
console.log("Linha 3")
